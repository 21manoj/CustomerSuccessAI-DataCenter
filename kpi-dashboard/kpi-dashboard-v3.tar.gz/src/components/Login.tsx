import React from "react";

const Login = () => <div>Login</div>;

export default Login;
