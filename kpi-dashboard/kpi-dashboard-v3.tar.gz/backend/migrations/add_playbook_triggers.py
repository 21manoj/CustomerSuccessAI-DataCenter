"""
Database migration script to add playbook_triggers table

Run this script to add the playbook_triggers table to your database
"""

import sys
import os

# Add parent directory to path to import models
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app, db
from models import PlaybookTrigger

def create_playbook_triggers_table():
    """Create the playbook_triggers table"""
    with app.app_context():
        try:
            # Create the table
            db.create_all()
            print("✅ Successfully created playbook_triggers table")
            
            # Verify table was created
            inspector = db.inspect(db.engine)
            tables = inspector.get_table_names()
            
            if 'playbook_triggers' in tables:
                print("✅ Verified: playbook_triggers table exists")
                
                # Show table columns
                columns = inspector.get_columns('playbook_triggers')
                print("\n📋 Table columns:")
                for col in columns:
                    print(f"   - {col['name']}: {col['type']}")
            else:
                print("❌ Warning: playbook_triggers table not found after creation")
            
        except Exception as e:
            print(f"❌ Error creating table: {e}")
            raise

if __name__ == '__main__':
    print("🚀 Starting database migration: add_playbook_triggers")
    print("=" * 60)
    create_playbook_triggers_table()
    print("=" * 60)
    print("✅ Migration completed successfully!")

