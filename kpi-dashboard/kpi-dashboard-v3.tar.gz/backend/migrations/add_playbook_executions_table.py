"""
Migration script to add playbook_executions table and update playbook_reports foreign key

This script:
1. Creates the playbook_executions table
2. Updates playbook_reports to have a foreign key to playbook_executions with CASCADE delete

Run: python add_playbook_executions_table.py
"""

import sys
import os

# Add parent directory to path to import app modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app, db
from models import PlaybookExecution, PlaybookReport
from sqlalchemy import inspect, text

def migrate_playbook_tables():
    """Create playbook_executions table and update foreign key"""
    with app.app_context():
        inspector = inspect(db.engine)
        
        # Step 1: Create playbook_executions table if it doesn't exist
        if 'playbook_executions' not in inspector.get_table_names():
            print("Creating playbook_executions table...")
            PlaybookExecution.__table__.create(db.engine)
            print("✓ Created table 'playbook_executions'")
            
            columns = [col['name'] for col in inspector.get_columns('playbook_executions')]
            print(f"✓ Table columns: {', '.join(columns)}")
        else:
            print("✓ Table 'playbook_executions' already exists")
        
        # Step 2: Check if we need to update playbook_reports foreign key
        # For SQLite, we need to check if the FK exists and recreate table if needed
        if 'playbook_reports' in inspector.get_table_names():
            print("\n Checking playbook_reports foreign key...")
            
            # Get foreign keys
            fks = inspector.get_foreign_keys('playbook_reports')
            has_cascade_fk = False
            
            for fk in fks:
                if fk['referred_table'] == 'playbook_executions' and 'ondelete' in fk.get('options', {}):
                    has_cascade_fk = True
                    break
            
            if not has_cascade_fk:
                print("⚠ Foreign key doesn't have CASCADE delete, will be updated on next schema migration")
                print("  For now, manual cleanup of reports when deleting executions will be handled in code")
            else:
                print("✓ Foreign key with CASCADE delete already configured")
        
        print("\n✓ Migration complete!")
        print("\nNext steps:")
        print("1. Restart the Flask server")
        print("2. Existing playbook executions will be loaded from memory and can be persisted")
        print("3. Future executions will automatically be saved to the database")

if __name__ == '__main__':
    print("Migrating playbook tables...")
    migrate_playbook_tables()

