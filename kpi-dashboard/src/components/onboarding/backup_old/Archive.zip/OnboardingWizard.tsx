/**
 * Customer Onboarding Wizard
 * ==========================
 * 
 * 6-step wizard for new customer onboarding:
 * 1. Business Context
 * 2. KPI Priority Ranking
 * 3. Event Severity Calibration
 * 4. Success Criteria
 * 5. Data Sources
 * 6. Review & Confirm
 */

import React, { useState } from 'react';
import {
  Building2, BarChart2, AlertTriangle, Target, Database, CheckCircle,
  ChevronLeft, ChevronRight, GripVertical, Upload, Link, Check,
  X, Info, Download, Rocket
} from 'lucide-react';

// ============================================================================
// TYPES
// ============================================================================

interface BusinessContext {
  company_name: string;
  industry: string;
  segments: string[];
  avg_deal_size: number;
  contract_model: string;
  csm_model: string;
}

interface PillarRanking {
  id: string;
  label: string;
  description: string;
  rank: number;
}

interface EventSeverity {
  id: string;
  name: string;
  severity: number;
  type: 'negative' | 'positive';
}

interface SuccessCriteria {
  healthy_min: number;
  at_risk_min: number;
  churn_alert: number;
  expansion_alert: number;
  prediction_horizon: number;
}

interface DataSource {
  id: string;
  name: string;
  type: 'file' | 'api';
  status: 'pending' | 'uploaded' | 'connected' | 'skipped';
  rows?: number;
  filename?: string;
}

interface OnboardingData {
  business: BusinessContext;
  pillars: PillarRanking[];
  events: EventSeverity[];
  criteria: SuccessCriteria;
  sources: DataSource[];
}

// ============================================================================
// DEFAULT VALUES
// ============================================================================

const DEFAULT_BUSINESS: BusinessContext = {
  company_name: '',
  industry: '',
  segments: [],
  avg_deal_size: 100000,
  contract_model: 'annual',
  csm_model: 'high_touch'
};

const DEFAULT_PILLARS: PillarRanking[] = [
  { id: 'performance', label: 'Performance', description: 'Uptime, speed, reliability', rank: 1 },
  { id: 'usage', label: 'Usage', description: 'Adoption, engagement, feature usage', rank: 2 },
  { id: 'business', label: 'Business', description: 'ROI, cost efficiency, value realized', rank: 3 },
  { id: 'relationship', label: 'Relationship', description: 'NPS, satisfaction, engagement', rank: 4 },
  { id: 'growth', label: 'Growth', description: 'Expansion, upsells, referrals', rank: 5 }
];

const DEFAULT_EVENTS: EventSeverity[] = [
  { id: 'outage', name: 'Critical Outage (>4 hours)', severity: 10, type: 'negative' },
  { id: 'escalation', name: 'Support Escalation', severity: 8, type: 'negative' },
  { id: 'exec_change', name: 'Executive Sponsor Change', severity: 7, type: 'negative' },
  { id: 'usage_drop', name: 'Usage Drop >20%', severity: 8, type: 'negative' },
  { id: 'missed_sla', name: 'Missed SLA', severity: 6, type: 'negative' },
  { id: 'nps_drop', name: 'NPS Score Drop (>10pts)', severity: 5, type: 'negative' },
  { id: 'late_payment', name: 'Late Payment (>30 days)', severity: 3, type: 'negative' },
  { id: 'qbr', name: 'QBR Completed', severity: 6, type: 'positive' },
  { id: 'expansion', name: 'Expansion Discussion', severity: 8, type: 'positive' },
  { id: 'reference', name: 'Reference/Testimonial', severity: 9, type: 'positive' }
];

const DEFAULT_CRITERIA: SuccessCriteria = {
  healthy_min: 70,
  at_risk_min: 50,
  churn_alert: 60,
  expansion_alert: 50,
  prediction_horizon: 90
};

const DEFAULT_SOURCES: DataSource[] = [
  { id: 'accounts', name: 'Account List', type: 'file', status: 'pending' },
  { id: 'kpis', name: 'Historical KPIs', type: 'file', status: 'pending' },
  { id: 'tickets', name: 'Support Tickets', type: 'file', status: 'pending' },
  { id: 'activities', name: 'CRM Activities', type: 'file', status: 'pending' },
  { id: 'salesforce', name: 'Salesforce', type: 'api', status: 'pending' },
  { id: 'zendesk', name: 'Zendesk', type: 'api', status: 'pending' },
  { id: 'slack', name: 'Slack', type: 'api', status: 'pending' }
];

// ============================================================================
// STEP COMPONENTS
// ============================================================================

// Step 1: Business Context
const Step1Business: React.FC<{
  data: BusinessContext;
  onChange: (data: BusinessContext) => void;
}> = ({ data, onChange }) => {
  const industries = ['SaaS', 'Hardware', 'Services', 'Healthcare', 'FinTech', 'Manufacturing', 'Other'];
  const segments = ['Enterprise', 'Mid-market', 'SMB', 'Startup'];
  const contractModels = ['Monthly', 'Annual', 'Multi-year'];
  const csmModels = ['High-touch', 'Tech-touch', 'Digital', 'Hybrid'];

  return (
    <div className="space-y-6">
      <div>
        <label className="block text-sm font-medium mb-2">Company Name *</label>
        <input
          type="text"
          value={data.company_name}
          onChange={(e) => onChange({ ...data, company_name: e.target.value })}
          className="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"
          placeholder="Enter your company name"
        />
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Industry *</label>
        <div className="grid grid-cols-4 gap-2">
          {industries.map((ind) => (
            <button
              key={ind}
              onClick={() => onChange({ ...data, industry: ind })}
              className={`px-4 py-2 rounded-lg border text-sm ${
                data.industry === ind
                  ? 'bg-blue-50 border-blue-500 text-blue-700'
                  : 'hover:bg-gray-50'
              }`}
            >
              {ind}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">Customer Segments *</label>
        <div className="grid grid-cols-4 gap-2">
          {segments.map((seg) => (
            <button
              key={seg}
              onClick={() => {
                const newSegments = data.segments.includes(seg)
                  ? data.segments.filter((s) => s !== seg)
                  : [...data.segments, seg];
                onChange({ ...data, segments: newSegments });
              }}
              className={`px-4 py-2 rounded-lg border text-sm flex items-center justify-center gap-2 ${
                data.segments.includes(seg)
                  ? 'bg-blue-50 border-blue-500 text-blue-700'
                  : 'hover:bg-gray-50'
              }`}
            >
              {data.segments.includes(seg) && <Check className="w-4 h-4" />}
              {seg}
            </button>
          ))}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium mb-2">
          Average Deal Size: ${data.avg_deal_size.toLocaleString()}
        </label>
        <input
          type="range"
          min={10000}
          max={1000000}
          step={10000}
          value={data.avg_deal_size}
          onChange={(e) => onChange({ ...data, avg_deal_size: Number(e.target.value) })}
          className="w-full"
        />
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>$10K</span>
          <span>$500K</span>
          <span>$1M+</span>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium mb-2">Contract Model</label>
          <select
            value={data.contract_model}
            onChange={(e) => onChange({ ...data, contract_model: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg"
          >
            {contractModels.map((model) => (
              <option key={model} value={model.toLowerCase().replace('-', '_')}>
                {model}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">CSM Model</label>
          <select
            value={data.csm_model}
            onChange={(e) => onChange({ ...data, csm_model: e.target.value })}
            className="w-full px-4 py-2 border rounded-lg"
          >
            {csmModels.map((model) => (
              <option key={model} value={model.toLowerCase().replace('-', '_')}>
                {model}
              </option>
            ))}
          </select>
        </div>
      </div>
    </div>
  );
};

// Step 2: KPI Priority Ranking
const Step2Pillars: React.FC<{
  data: PillarRanking[];
  onChange: (data: PillarRanking[]) => void;
}> = ({ data, onChange }) => {
  const [dragging, setDragging] = useState<number | null>(null);

  const handleDragStart = (index: number) => {
    setDragging(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (dragging === null || dragging === index) return;

    const newData = [...data];
    const draggedItem = newData[dragging];
    newData.splice(dragging, 1);
    newData.splice(index, 0, draggedItem);
    
    // Update ranks
    newData.forEach((item, i) => {
      item.rank = i + 1;
    });

    onChange(newData);
    setDragging(index);
  };

  const handleDragEnd = () => {
    setDragging(null);
  };

  return (
    <div className="space-y-4">
      <p className="text-gray-600 mb-4">
        Drag to reorder by importance to YOUR business. #1 = Most Important
      </p>
      
      {data.sort((a, b) => a.rank - b.rank).map((pillar, index) => (
        <div
          key={pillar.id}
          draggable
          onDragStart={() => handleDragStart(index)}
          onDragOver={(e) => handleDragOver(e, index)}
          onDragEnd={handleDragEnd}
          className={`flex items-center gap-4 p-4 bg-white border rounded-lg cursor-move transition-all ${
            dragging === index ? 'opacity-50 scale-95' : 'hover:shadow-md'
          }`}
        >
          <div className="flex items-center gap-3">
            <GripVertical className="w-5 h-5 text-gray-400" />
            <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${
              index === 0 ? 'bg-blue-600' :
              index === 1 ? 'bg-blue-500' :
              index === 2 ? 'bg-blue-400' :
              index === 3 ? 'bg-gray-400' :
              'bg-gray-300'
            }`}>
              {pillar.rank}
            </div>
          </div>
          <div className="flex-1">
            <h4 className="font-medium">{pillar.label}</h4>
            <p className="text-sm text-gray-500">{pillar.description}</p>
          </div>
          <div className="text-sm text-gray-400">
            {index === 0 && '← Most Important'}
            {index === data.length - 1 && '← Least Important'}
          </div>
        </div>
      ))}

      <div className="mt-6 p-4 bg-blue-50 rounded-lg">
        <p className="text-sm text-blue-800">
          <strong>Weight Impact:</strong> Your ranking will adjust pillar weights.
          #1 gets ~30%, #2-3 get ~20%, #4-5 get ~15%.
        </p>
      </div>
    </div>
  );
};

// Step 3: Event Severity
const Step3Events: React.FC<{
  data: EventSeverity[];
  onChange: (data: EventSeverity[]) => void;
}> = ({ data, onChange }) => {
  const handleSeverityChange = (id: string, severity: number) => {
    const newData = data.map((event) =>
      event.id === id ? { ...event, severity } : event
    );
    onChange(newData);
  };

  return (
    <div className="space-y-4">
      <p className="text-gray-600 mb-4">
        Rate how severe each event is for YOUR customers (1 = Minor, 10 = Critical)
      </p>

      <div className="space-y-3">
        <h4 className="font-medium text-red-700">Negative Events</h4>
        {data.filter((e) => e.type === 'negative').map((event) => (
          <div key={event.id} className="flex items-center gap-4 p-3 bg-red-50 rounded-lg">
            <div className="flex-1">
              <p className="font-medium text-sm">{event.name}</p>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              value={event.severity}
              onChange={(e) => handleSeverityChange(event.id, Number(e.target.value))}
              className="w-32"
            />
            <span className="w-8 text-center font-bold text-red-700">{event.severity}</span>
          </div>
        ))}
      </div>

      <div className="space-y-3 mt-6">
        <h4 className="font-medium text-green-700">Positive Events</h4>
        {data.filter((e) => e.type === 'positive').map((event) => (
          <div key={event.id} className="flex items-center gap-4 p-3 bg-green-50 rounded-lg">
            <div className="flex-1">
              <p className="font-medium text-sm">{event.name}</p>
            </div>
            <input
              type="range"
              min={1}
              max={10}
              value={event.severity}
              onChange={(e) => handleSeverityChange(event.id, Number(e.target.value))}
              className="w-32"
            />
            <span className="w-8 text-center font-bold text-green-700">{event.severity}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

// Step 4: Success Criteria
const Step4Criteria: React.FC<{
  data: SuccessCriteria;
  onChange: (data: SuccessCriteria) => void;
}> = ({ data, onChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h4 className="font-medium mb-4">Health Score Thresholds</h4>
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm">Healthy Minimum</span>
              <span className="text-sm font-medium text-green-600">{data.healthy_min}+</span>
            </div>
            <input
              type="range"
              min={60}
              max={90}
              value={data.healthy_min}
              onChange={(e) => onChange({ ...data, healthy_min: Number(e.target.value) })}
              className="w-full"
            />
          </div>
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm">At-Risk Minimum</span>
              <span className="text-sm font-medium text-yellow-600">{data.at_risk_min} - {data.healthy_min - 1}</span>
            </div>
            <input
              type="range"
              min={30}
              max={data.healthy_min - 10}
              value={data.at_risk_min}
              onChange={(e) => onChange({ ...data, at_risk_min: Number(e.target.value) })}
              className="w-full"
            />
          </div>
        </div>
        
        <div className="mt-4 h-6 rounded-full overflow-hidden flex">
          <div className="bg-red-500" style={{ width: `${data.at_risk_min}%` }} />
          <div className="bg-yellow-500" style={{ width: `${data.healthy_min - data.at_risk_min}%` }} />
          <div className="bg-green-500" style={{ width: `${100 - data.healthy_min}%` }} />
        </div>
        <div className="flex justify-between text-xs text-gray-500 mt-1">
          <span>0 (Critical)</span>
          <span>{data.at_risk_min}</span>
          <span>{data.healthy_min}</span>
          <span>100</span>
        </div>
      </div>

      <div className="border-t pt-6">
        <h4 className="font-medium mb-4">Alert Thresholds</h4>
        <div className="grid grid-cols-2 gap-6">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm">Churn Alert When</span>
              <span className="text-sm font-medium text-red-600">≥ {data.churn_alert}%</span>
            </div>
            <input
              type="range"
              min={30}
              max={80}
              value={data.churn_alert}
              onChange={(e) => onChange({ ...data, churn_alert: Number(e.target.value) })}
              className="w-full"
            />
          </div>
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm">Expansion Alert When</span>
              <span className="text-sm font-medium text-green-600">≥ {data.expansion_alert}%</span>
            </div>
            <input
              type="range"
              min={30}
              max={80}
              value={data.expansion_alert}
              onChange={(e) => onChange({ ...data, expansion_alert: Number(e.target.value) })}
              className="w-full"
            />
          </div>
        </div>
      </div>

      <div className="border-t pt-6">
        <h4 className="font-medium mb-4">Prediction Horizon</h4>
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm">Predict outcomes for next</span>
            <span className="text-sm font-medium">{data.prediction_horizon} days</span>
          </div>
          <input
            type="range"
            min={30}
            max={180}
            step={30}
            value={data.prediction_horizon}
            onChange={(e) => onChange({ ...data, prediction_horizon: Number(e.target.value) })}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>30 days</span>
            <span>90 days</span>
            <span>180 days</span>
          </div>
        </div>
      </div>
    </div>
  );
};

// Step 5: Data Sources
const Step5Sources: React.FC<{
  data: DataSource[];
  onChange: (data: DataSource[]) => void;
}> = ({ data, onChange }) => {
  const handleFileUpload = (id: string, file: File) => {
    // Simulate file upload
    const newData = data.map((source) =>
      source.id === id
        ? { ...source, status: 'uploaded' as const, filename: file.name, rows: Math.floor(Math.random() * 1000) + 50 }
        : source
    );
    onChange(newData);
  };

  const handleConnect = (id: string) => {
    // Simulate API connection
    const newData = data.map((source) =>
      source.id === id
        ? { ...source, status: 'connected' as const }
        : source
    );
    onChange(newData);
  };

  const handleSkip = (id: string) => {
    const newData = data.map((source) =>
      source.id === id ? { ...source, status: 'skipped' as const } : source
    );
    onChange(newData);
  };

  const fileSources = data.filter((s) => s.type === 'file');
  const apiSources = data.filter((s) => s.type === 'api');

  return (
    <div className="space-y-6">
      <div>
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Upload className="w-5 h-5" />
          File Uploads
        </h4>
        <div className="space-y-2">
          {fileSources.map((source) => (
            <div key={source.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                {source.status === 'uploaded' ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : source.status === 'skipped' ? (
                  <X className="w-5 h-5 text-gray-400" />
                ) : (
                  <div className="w-5 h-5 border-2 border-gray-300 rounded" />
                )}
                <div>
                  <p className="font-medium">{source.name}</p>
                  {source.status === 'uploaded' && (
                    <p className="text-xs text-gray-500">{source.filename} • {source.rows} rows</p>
                  )}
                  {source.id === 'accounts' && (
                    <p className="text-xs text-blue-600">Required</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-2">
                {source.status !== 'uploaded' && (
                  <>
                    <label className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded cursor-pointer hover:bg-blue-200">
                      Upload
                      <input
                        type="file"
                        accept=".csv"
                        className="hidden"
                        onChange={(e) => {
                          if (e.target.files?.[0]) {
                            handleFileUpload(source.id, e.target.files[0]);
                          }
                        }}
                      />
                    </label>
                    {source.id !== 'accounts' && (
                      <button
                        onClick={() => handleSkip(source.id)}
                        className="px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200 rounded"
                      >
                        Skip
                      </button>
                    )}
                  </>
                )}
                {source.status === 'uploaded' && (
                  <span className="text-sm text-green-600">✓ Uploaded</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="border-t pt-6">
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Link className="w-5 h-5" />
          API Connections (Optional)
        </h4>
        <div className="space-y-2">
          {apiSources.map((source) => (
            <div key={source.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <div className="flex items-center gap-3">
                {source.status === 'connected' ? (
                  <CheckCircle className="w-5 h-5 text-green-500" />
                ) : source.status === 'skipped' ? (
                  <X className="w-5 h-5 text-gray-400" />
                ) : (
                  <div className="w-5 h-5 border-2 border-gray-300 rounded" />
                )}
                <p className="font-medium">{source.name}</p>
              </div>
              <div className="flex items-center gap-2">
                {source.status === 'pending' && (
                  <>
                    <button
                      onClick={() => handleConnect(source.id)}
                      className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                    >
                      Connect
                    </button>
                    <button
                      onClick={() => handleSkip(source.id)}
                      className="px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200 rounded"
                    >
                      Skip
                    </button>
                  </>
                )}
                {source.status === 'connected' && (
                  <span className="text-sm text-green-600">✓ Connected</span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// Step 6: Review
const Step6Review: React.FC<{
  data: OnboardingData;
}> = ({ data }) => {
  const pillarWeights = data.pillars.map((p, i) => ({
    ...p,
    weight: i === 0 ? 30 : i <= 2 ? 20 : 15
  }));

  return (
    <div className="space-y-6">
      <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
        <div className="flex items-center gap-2 text-green-800">
          <CheckCircle className="w-5 h-5" />
          <span className="font-medium">Configuration Complete!</span>
        </div>
        <p className="text-sm text-green-700 mt-1">
          Review your settings below before completing setup.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-6">
        {/* Business Context */}
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Building2 className="w-4 h-4" />
            Business Profile
          </h4>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-gray-500">Company</dt>
              <dd className="font-medium">{data.business.company_name || 'Not set'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">Industry</dt>
              <dd>{data.business.industry || 'Not set'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">Segments</dt>
              <dd>{data.business.segments.join(', ') || 'Not set'}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">Avg Deal</dt>
              <dd>${data.business.avg_deal_size.toLocaleString()}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">CSM Model</dt>
              <dd>{data.business.csm_model.replace('_', '-')}</dd>
            </div>
          </dl>
        </div>

        {/* Pillar Weights */}
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <BarChart2 className="w-4 h-4" />
            Pillar Weights
          </h4>
          <div className="space-y-2">
            {pillarWeights.sort((a, b) => a.rank - b.rank).map((pillar) => (
              <div key={pillar.id} className="flex items-center justify-between text-sm">
                <span>#{pillar.rank} {pillar.label}</span>
                <span className="font-medium">{pillar.weight}%</span>
              </div>
            ))}
          </div>
        </div>

        {/* Thresholds */}
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Target className="w-4 h-4" />
            Thresholds
          </h4>
          <dl className="space-y-2 text-sm">
            <div className="flex justify-between">
              <dt className="text-gray-500">Healthy</dt>
              <dd className="text-green-600 font-medium">{data.criteria.healthy_min}+</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">At-Risk</dt>
              <dd className="text-yellow-600 font-medium">{data.criteria.at_risk_min}-{data.criteria.healthy_min - 1}</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">Churn Alert</dt>
              <dd className="text-red-600 font-medium">≥{data.criteria.churn_alert}%</dd>
            </div>
            <div className="flex justify-between">
              <dt className="text-gray-500">Expansion Alert</dt>
              <dd className="text-green-600 font-medium">≥{data.criteria.expansion_alert}%</dd>
            </div>
          </dl>
        </div>

        {/* Data Sources */}
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-3 flex items-center gap-2">
            <Database className="w-4 h-4" />
            Data Sources
          </h4>
          <div className="space-y-2 text-sm">
            {data.sources.filter((s) => s.status !== 'pending' && s.status !== 'skipped').map((source) => (
              <div key={source.id} className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-green-500" />
                <span>{source.name}</span>
                {source.rows && <span className="text-gray-500">({source.rows} rows)</span>}
              </div>
            ))}
            {data.sources.filter((s) => s.status === 'pending' || s.status === 'skipped').length > 0 && (
              <p className="text-gray-500">
                {data.sources.filter((s) => s.status === 'skipped').length} skipped
              </p>
            )}
          </div>
        </div>
      </div>

      <div className="flex items-center justify-center gap-4 pt-4">
        <button className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-100 rounded flex items-center gap-2">
          <Download className="w-4 h-4" />
          Download Config
        </button>
      </div>
    </div>
  );
};

// ============================================================================
// MAIN WIZARD COMPONENT
// ============================================================================

const OnboardingWizard: React.FC<{
  onComplete?: (data: OnboardingData) => void;
  onCancel?: () => void;
}> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(1);
  const [business, setBusiness] = useState<BusinessContext>(DEFAULT_BUSINESS);
  const [pillars, setPillars] = useState<PillarRanking[]>(DEFAULT_PILLARS);
  const [events, setEvents] = useState<EventSeverity[]>(DEFAULT_EVENTS);
  const [criteria, setCriteria] = useState<SuccessCriteria>(DEFAULT_CRITERIA);
  const [sources, setSources] = useState<DataSource[]>(DEFAULT_SOURCES);

  const steps = [
    { num: 1, title: 'Business Context', icon: <Building2 className="w-5 h-5" /> },
    { num: 2, title: 'KPI Priorities', icon: <BarChart2 className="w-5 h-5" /> },
    { num: 3, title: 'Event Severity', icon: <AlertTriangle className="w-5 h-5" /> },
    { num: 4, title: 'Success Criteria', icon: <Target className="w-5 h-5" /> },
    { num: 5, title: 'Data Sources', icon: <Database className="w-5 h-5" /> },
    { num: 6, title: 'Review', icon: <CheckCircle className="w-5 h-5" /> }
  ];

  const canProceed = () => {
    switch (step) {
      case 1:
        return business.company_name && business.industry && business.segments.length > 0;
      case 5:
        return sources.find((s) => s.id === 'accounts')?.status === 'uploaded';
      default:
        return true;
    }
  };

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleComplete = async () => {
    setIsSubmitting(true);
    setSubmitError(null);

    try {
      // Convert pillar rankings to weights
      const pillarWeights = convertRankingsToWeights(pillars);
      
      // Prepare data for API
      const payload = {
        company_name: business.company_name,
        company_email: business.company_name.toLowerCase().replace(/\s+/g, '') + '@example.com', // TODO: Get from business context
        admin_name: business.company_name + ' Admin', // TODO: Get from team data
        admin_email: 'admin@' + business.company_name.toLowerCase().replace(/\s+/g, '') + '.com', // TODO: Get from team data
        admin_password: 'TempPassword123!', // TODO: Generate secure password or get from user
        phone: '', // TODO: Get from business context
        vertical: 'dc2_s', // Data Center vertical
        kpi_upload_mode: 'account_rollup',
        weights: pillarWeights,
        pillars: pillars.map(p => ({ id: p.id, label: p.label, rank: p.rank })),
        criteria: criteria,
        sources: sources.filter(s => s.status === 'uploaded' || s.status === 'connected')
      };

      const response = await fetch('/api/onboarding/complete', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: 'Failed to complete onboarding' }));
        throw new Error(errorData.message || `HTTP ${response.status}`);
      }

      const result = await response.json();
      
      // Call parent callback if provided
      if (onComplete) {
        onComplete({ business, pillars, events, criteria, sources });
      }

      // Redirect to dashboard (using window.location for now)
      window.location.href = '/dc-dashboard';
      
    } catch (error) {
      console.error('Onboarding completion error:', error);
      setSubmitError(error instanceof Error ? error.message : 'Failed to complete onboarding. Please try again.');
      setIsSubmitting(false);
    }
  };

  // Convert pillar rankings to weights
  const convertRankingsToWeights = (pillarRankings: PillarRanking[]): Record<string, number> => {
    // Sort by rank (1 = highest priority)
    const sorted = [...pillarRankings].sort((a, b) => a.rank - b.rank);
    
    // Calculate inverse rank weights (rank 1 gets highest weight)
    const totalInverse = sorted.reduce((sum, p) => sum + 1 / p.rank, 0);
    const weights: Record<string, number> = {};
    
    sorted.forEach((pillar) => {
      // Map generic pillar IDs to DC2_S pillar IDs
      const dc2sPillarId = mapPillarToDC2S(pillar.id);
      weights[dc2sPillarId] = Math.round((1 / pillar.rank / totalInverse) * 100) / 100;
    });
    
    // Normalize to ensure sum = 1.0
    const sum = Object.values(weights).reduce((a, b) => a + b, 0);
    if (sum > 0) {
      Object.keys(weights).forEach(key => {
        weights[key] = Math.round((weights[key] / sum) * 100) / 100;
      });
    }
    
    return weights;
  };

  // Map generic pillar IDs to DC2_S 5-Pillar model
  const mapPillarToDC2S = (genericId: string): string => {
    const mapping: Record<string, string> = {
      'performance': 'P1_deployment_velocity',
      'usage': 'P2_operational_stability',
      'business': 'P3_ai_workload_performance',
      'relationship': 'P4_channel_partner_health',
      'growth': 'P5_expansion_revenue'
    };
    return mapping[genericId] || genericId;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">Customer Onboarding Wizard</h2>
              <p className="text-blue-100 text-sm">Step {step} of 6</p>
            </div>
            <button onClick={onCancel} className="p-1 hover:bg-white/20 rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {/* Progress */}
          <div className="flex items-center gap-2 mt-4">
            {steps.map((s) => (
              <div key={s.num} className="flex-1">
                <div className={`h-1 rounded-full ${
                  s.num < step ? 'bg-white' :
                  s.num === step ? 'bg-white/70' :
                  'bg-white/30'
                }`} />
              </div>
            ))}
          </div>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-8 py-4 border-b bg-gray-50">
          {steps.map((s) => (
            <div
              key={s.num}
              className={`flex items-center gap-2 ${
                s.num === step ? 'text-blue-600' :
                s.num < step ? 'text-green-600' :
                'text-gray-400'
              }`}
            >
              {s.num < step ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                s.icon
              )}
              <span className={`text-sm ${s.num === step ? 'font-medium' : ''}`}>
                {s.title}
              </span>
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {submitError && (
            <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2 text-red-800">
                <AlertTriangle className="w-5 h-5" />
                <span className="font-medium">Error:</span>
                <span>{submitError}</span>
              </div>
            </div>
          )}
          {step === 1 && <Step1Business data={business} onChange={setBusiness} />}
          {step === 2 && <Step2Pillars data={pillars} onChange={setPillars} />}
          {step === 3 && <Step3Events data={events} onChange={setEvents} />}
          {step === 4 && <Step4Criteria data={criteria} onChange={setCriteria} />}
          {step === 5 && <Step5Sources data={sources} onChange={setSources} />}
          {step === 6 && <Step6Review data={{ business, pillars, events, criteria, sources }} />}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t flex items-center justify-between">
          <button
            onClick={() => setStep(step - 1)}
            disabled={step === 1}
            className={`px-4 py-2 rounded flex items-center gap-2 ${
              step === 1
                ? 'text-gray-400 cursor-not-allowed'
                : 'text-gray-600 hover:bg-gray-200'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </button>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => onCancel?.()}
              className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded"
            >
              Cancel
            </button>
            
            {step < 6 ? (
              <button
                onClick={() => setStep(step + 1)}
                disabled={!canProceed()}
                className={`px-4 py-2 rounded flex items-center gap-2 ${
                  canProceed()
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                disabled={isSubmitting}
                className={`px-6 py-2 rounded flex items-center gap-2 ${
                  isSubmitting
                    ? 'bg-gray-400 text-white cursor-not-allowed'
                    : 'bg-green-600 text-white hover:bg-green-700'
                }`}
              >
                {isSubmitting ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Submitting...
                  </>
                ) : (
                  <>
                    <Rocket className="w-4 h-4" />
                    Complete Setup
                  </>
                )}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingWizard;
