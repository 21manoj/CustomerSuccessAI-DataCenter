/**
 * Enhanced Onboarding Wizard - Main Orchestrator
 * 
 * Complete 8-step wizard for new customer onboarding
 */

import React, { useState, useEffect } from 'react';
import {
  Building2, BarChart2, AlertTriangle, Target, Database, CheckCircle,
  ChevronLeft, ChevronRight, X, Rocket, CreditCard, Users, BookOpen
} from 'lucide-react';

// Types
import { OnboardingData } from './OnboardingWizard.types';

// Configuration
import {
  DEFAULT_ACCOUNT,
  DEFAULT_BUSINESS,
  DEFAULT_CRITERIA,
  getDefaultSources,
  getPillarsForVertical,
  getEventsForVertical
} from './OnboardingWizard.config';

// Step Components
import { Step0Account } from './Step0Account';
import { Step1Business } from './Step1Business';
import { Step2Pillars } from './Step2Pillars';
import { Step3Events } from './Step3Events';
import { Step4Criteria } from './Step4Criteria';
import { Step5Sources } from './Step5Sources';
import { Step6Review } from './Step6Review';
import { Step7Team } from './Step7Team';
import { Step8Training } from './Step8Training';

// ============================================================================
// MAIN WIZARD COMPONENT
// ============================================================================

interface OnboardingWizardProps {
  onComplete: (data: OnboardingData) => void;
  onCancel: () => void;
}

export const OnboardingWizard: React.FC<OnboardingWizardProps> = ({ onComplete, onCancel }) => {
  const [step, setStep] = useState(0);
  const [account, setAccount] = useState(DEFAULT_ACCOUNT);
  const [business, setBusiness] = useState(DEFAULT_BUSINESS);
  const [pillars, setPillars] = useState(getPillarsForVertical(null));
  const [events, setEvents] = useState(getEventsForVertical(null));
  const [criteria, setCriteria] = useState(DEFAULT_CRITERIA);
  const [sources, setSources] = useState(getDefaultSources(null));
  const [team, setTeam] = useState<any[]>([]);
  const [skipTraining, setSkipTraining] = useState(false);

  // Update pillars and events when vertical changes
  useEffect(() => {
    if (business.vertical) {
      setPillars(getPillarsForVertical(business.vertical));
      setEvents(getEventsForVertical(business.vertical));
      setSources(getDefaultSources(business.vertical));
    }
  }, [business.vertical]);

  const steps = [
    { num: 0, title: 'Account & Billing', icon: <CreditCard className="w-5 h-5" /> },
    { num: 1, title: 'Business Context', icon: <Building2 className="w-5 h-5" /> },
    { num: 2, title: 'KPI Priorities', icon: <BarChart2 className="w-5 h-5" /> },
    { num: 3, title: 'Event Severity', icon: <AlertTriangle className="w-5 h-5" /> },
    { num: 4, title: 'Success Criteria', icon: <Target className="w-5 h-5" /> },
    { num: 5, title: 'Data Sources', icon: <Database className="w-5 h-5" /> },
    { num: 6, title: 'Review', icon: <CheckCircle className="w-5 h-5" /> },
    { num: 7, title: 'Team Setup', icon: <Users className="w-5 h-5" /> },
    { num: 8, title: 'Training', icon: <BookOpen className="w-5 h-5" /> }
  ];

  const canProceed = (): boolean => {
    switch (step) {
      case 0:
        return !!(
          account.email &&
          account.password.length >= 8 &&
          account.company_domain &&
          account.subscription_plan
        );
      case 1:
        return !!(
          business.vertical &&
          business.company_name &&
          business.industry &&
          business.segments.length > 0
        );
      case 5:
        return sources.find((s) => s.id === 'accounts')?.status === 'uploaded';
      default:
        return true;
    }
  };

  const handleComplete = () => {
    const onboardingData: OnboardingData = {
      account,
      business,
      pillars,
      events,
      criteria,
      sources,
      team,
      skip_training: skipTraining
    };
    onComplete(onboardingData);
  };

  const totalSteps = steps.length;
  const isLastStep = step === totalSteps - 1;
  const isFirstStep = step === 0;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">Customer Onboarding Wizard</h2>
              <p className="text-blue-100 text-sm">Step {step + 1} of {totalSteps}</p>
            </div>
            <button onClick={onCancel} className="p-1 hover:bg-white/20 rounded">
              <X className="w-5 h-5" />
            </button>
          </div>
          
          {/* Progress Bar */}
          <div className="flex items-center gap-1 mt-4">
            {steps.map((s) => (
              <div key={s.num} className="flex-1">
                <div className={`h-1 rounded-full ${
                  s.num < step ? 'bg-white' :
                  s.num === step ? 'bg-white/70' :
                  'bg-white/30'
                }`} />
              </div>
            ))}
          </div>
        </div>

        {/* Step Indicator */}
        <div className="flex items-center justify-center gap-4 py-4 border-b bg-gray-50 overflow-x-auto">
          {steps.map((s) => (
            <div
              key={s.num}
              className={`flex items-center gap-2 whitespace-nowrap ${
                s.num === step ? 'text-blue-600' :
                s.num < step ? 'text-green-600' :
                'text-gray-400'
              }`}
            >
              {s.num < step ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                s.icon
              )}
              <span className={`text-sm ${s.num === step ? 'font-medium' : ''}`}>
                {s.title}
              </span>
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {step === 0 && <Step0Account data={account} onChange={setAccount} />}
          {step === 1 && <Step1Business data={business} onChange={setBusiness} />}
          {step === 2 && <Step2Pillars data={pillars} onChange={setPillars} />}
          {step === 3 && <Step3Events data={events} onChange={setEvents} />}
          {step === 4 && <Step4Criteria data={criteria} onChange={setCriteria} />}
          {step === 5 && <Step5Sources data={sources} onChange={setSources} />}
          {step === 6 && <Step6Review data={{ account, business, pillars, events, criteria, sources, team, skip_training: skipTraining }} />}
          {step === 7 && <Step7Team data={team} onChange={setTeam} />}
          {step === 8 && <Step8Training skipTraining={skipTraining} onSkipChange={setSkipTraining} />}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t flex items-center justify-between">
          <button
            onClick={() => setStep(step - 1)}
            disabled={isFirstStep}
            className={`px-4 py-2 rounded flex items-center gap-2 ${
              isFirstStep
                ? 'text-gray-400 cursor-not-allowed'
                : 'text-gray-600 hover:bg-gray-200'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            Back
          </button>
          
          <div className="flex items-center gap-3">
            <button
              onClick={onCancel}
              className="px-4 py-2 text-gray-600 hover:bg-gray-200 rounded"
            >
              Cancel
            </button>
            
            {!isLastStep ? (
              <button
                onClick={() => setStep(step + 1)}
                disabled={!canProceed()}
                className={`px-4 py-2 rounded flex items-center gap-2 ${
                  canProceed()
                    ? 'bg-blue-600 text-white hover:bg-blue-700'
                    : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                }`}
              >
                Next
                <ChevronRight className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={handleComplete}
                className="px-6 py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center gap-2"
              >
                <Rocket className="w-4 h-4" />
                Complete Setup
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OnboardingWizard;
