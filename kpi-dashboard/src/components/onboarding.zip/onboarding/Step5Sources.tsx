/**
 * Step 5: Data Sources with Validation and Preview
 */

import React, { useState } from 'react';
import { Upload, Link, CheckCircle, X, Eye, AlertCircle, Loader } from 'lucide-react';
import { DataSource } from './OnboardingWizard.types';
import { validateCSV, previewCSV, testAPIConnection } from './OnboardingWizard.utils';

interface Step5SourcesProps {
  data: DataSource[];
  onChange: (data: DataSource[]) => void;
}

export const Step5Sources: React.FC<Step5SourcesProps> = ({ data, onChange }) => {
  const [previewSource, setPreviewSource] = useState<string | null>(null);
  const [apiConfigSource, setApiConfigSource] = useState<string | null>(null);

  const handleFileUpload = async (id: string, file: File) => {
    // Set to validating state
    const newData = data.map((source) =>
      source.id === id ? { ...source, status: 'validating' as const, filename: file.name } : source
    );
    onChange(newData);

    try {
      // Validate CSV
      const requiredColumns = id === 'accounts' ? ['account_id', 'customer_id', 'account_name'] : undefined;
      const validation = await validateCSV(file, requiredColumns);

      // Preview first 5 rows
      const preview = await previewCSV(file, 5);

      // Update source with validation results
      const updatedData = newData.map((source) =>
        source.id === id
          ? {
              ...source,
              status: validation.valid ? ('uploaded' as const) : ('error' as const),
              rows: validation.row_count,
              preview,
              validation
            }
          : source
      );
      onChange(updatedData);
    } catch (error) {
      const updatedData = newData.map((source) =>
        source.id === id
          ? {
              ...source,
              status: 'error' as const,
              validation: {
                valid: false,
                errors: [error instanceof Error ? error.message : 'Validation failed'],
                warnings: []
              }
            }
          : source
      );
      onChange(updatedData);
    }
  };

  const handleConnectAPI = async (id: string) => {
    const source = data.find(s => s.id === id);
    if (!source || !source.api_config) return;

    const newData = data.map((s) =>
      s.id === id ? { ...s, status: 'validating' as const } : s
    );
    onChange(newData);

    try {
      const result = await testAPIConnection({
        endpoint: source.api_config.endpoint || '',
        api_key: source.api_config.api_key,
        auth_type: source.api_config.auth_type
      });

      const updatedData = newData.map((s) =>
        s.id === id
          ? {
              ...s,
              status: result.success ? ('connected' as const) : ('error' as const),
              api_config: {
                ...s.api_config!,
                connected_at: result.success ? new Date().toISOString() : undefined
              },
              validation: {
                valid: result.success,
                errors: result.success ? [] : [result.message],
                warnings: []
              }
            }
          : s
      );
      onChange(updatedData);
    } catch (error) {
      const updatedData = newData.map((s) =>
        s.id === id
          ? {
              ...s,
              status: 'error' as const,
              validation: {
                valid: false,
                errors: [error instanceof Error ? error.message : 'Connection failed'],
                warnings: []
              }
            }
          : s
      );
      onChange(updatedData);
    }

    setApiConfigSource(null);
  };

  const handleSkip = (id: string) => {
    const newData = data.map((source) =>
      source.id === id ? { ...source, status: 'skipped' as const } : source
    );
    onChange(newData);
  };

  const fileSources = data.filter((s) => s.type === 'file');
  const apiSources = data.filter((s) => s.type === 'api');

  return (
    <div className="space-y-6">
      {/* File Uploads */}
      <div>
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Upload className="w-5 h-5" />
          File Uploads
        </h4>
        <div className="space-y-2">
          {fileSources.map((source) => (
            <div key={source.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  {source.status === 'uploaded' ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : source.status === 'error' ? (
                    <AlertCircle className="w-5 h-5 text-red-500" />
                  ) : source.status === 'validating' ? (
                    <Loader className="w-5 h-5 text-blue-500 animate-spin" />
                  ) : source.status === 'skipped' ? (
                    <X className="w-5 h-5 text-gray-400" />
                  ) : (
                    <div className="w-5 h-5 border-2 border-gray-300 rounded" />
                  )}
                  <div className="flex-1">
                    <p className="font-medium">{source.name}</p>
                    {source.status === 'uploaded' && source.filename && (
                      <p className="text-xs text-gray-500">{source.filename} • {source.rows} rows</p>
                    )}
                    {source.id === 'accounts' && (
                      <p className="text-xs text-blue-600">Required</p>
                    )}
                    {source.validation && (
                      <div className="mt-2">
                        {source.validation.errors.map((error, i) => (
                          <p key={i} className="text-xs text-red-600">⚠️ {error}</p>
                        ))}
                        {source.validation.warnings.map((warning, i) => (
                          <p key={i} className="text-xs text-yellow-600">ℹ️ {warning}</p>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {source.status === 'uploaded' && source.preview && (
                    <button
                      onClick={() => setPreviewSource(previewSource === source.id ? null : source.id)}
                      className="px-3 py-1.5 text-sm bg-gray-100 text-gray-700 rounded hover:bg-gray-200 flex items-center gap-1"
                    >
                      <Eye className="w-4 h-4" />
                      Preview
                    </button>
                  )}
                  {source.status !== 'uploaded' && source.status !== 'validating' && (
                    <>
                      <label className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded cursor-pointer hover:bg-blue-200">
                        Upload
                        <input
                          type="file"
                          accept=".csv"
                          className="hidden"
                          onChange={(e) => {
                            if (e.target.files?.[0]) {
                              handleFileUpload(source.id, e.target.files[0]);
                            }
                          }}
                        />
                      </label>
                      {source.id !== 'accounts' && (
                        <button
                          onClick={() => handleSkip(source.id)}
                          className="px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200 rounded"
                        >
                          Skip
                        </button>
                      )}
                    </>
                  )}
                  {source.status === 'uploaded' && (
                    <span className="text-sm text-green-600">✓ Uploaded</span>
                  )}
                  {source.status === 'validating' && (
                    <span className="text-sm text-blue-600">Validating...</span>
                  )}
                </div>
              </div>
              {/* Preview Table */}
              {previewSource === source.id && source.preview && (
                <div className="mt-4 border rounded-lg overflow-hidden">
                  <div className="bg-gray-50 px-4 py-2 text-sm font-medium border-b">
                    Preview (first 5 rows)
                  </div>
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead className="bg-gray-100">
                        <tr>
                          {Object.keys(source.preview[0] || {}).map((key) => (
                            <th key={key} className="px-3 py-2 text-left border-b">
                              {key}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {source.preview.map((row, i) => (
                          <tr key={i} className="border-b">
                            {Object.values(row).map((cell, j) => (
                              <td key={j} className="px-3 py-2">
                                {String(cell)}
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* API Connections */}
      <div className="border-t pt-6">
        <h4 className="font-medium mb-3 flex items-center gap-2">
          <Link className="w-5 h-5" />
          API Connections (Optional)
        </h4>
        <div className="space-y-2">
          {apiSources.map((source) => (
            <div key={source.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3 flex-1">
                  {source.status === 'connected' ? (
                    <CheckCircle className="w-5 h-5 text-green-500" />
                  ) : source.status === 'error' ? (
                    <AlertCircle className="w-5 h-5 text-red-500" />
                  ) : source.status === 'validating' ? (
                    <Loader className="w-5 h-5 text-blue-500 animate-spin" />
                  ) : source.status === 'skipped' ? (
                    <X className="w-5 h-5 text-gray-400" />
                  ) : (
                    <div className="w-5 h-5 border-2 border-gray-300 rounded" />
                  )}
                  <p className="font-medium">{source.name}</p>
                  {source.validation && source.validation.errors.length > 0 && (
                    <p className="text-xs text-red-600">{source.validation.errors[0]}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  {source.status === 'pending' && (
                    <>
                      <button
                        onClick={() => setApiConfigSource(apiConfigSource === source.id ? null : source.id)}
                        className="px-3 py-1.5 text-sm bg-blue-100 text-blue-700 rounded hover:bg-blue-200"
                      >
                        Configure
                      </button>
                      <button
                        onClick={() => handleSkip(source.id)}
                        className="px-3 py-1.5 text-sm text-gray-600 hover:bg-gray-200 rounded"
                      >
                        Skip
                      </button>
                    </>
                  )}
                  {source.status === 'connected' && (
                    <span className="text-sm text-green-600">✓ Connected</span>
                  )}
                  {source.status === 'validating' && (
                    <span className="text-sm text-blue-600">Testing...</span>
                  )}
                </div>
              </div>
              {/* API Configuration Form */}
              {apiConfigSource === source.id && (
                <div className="mt-4 p-4 bg-gray-50 rounded-lg space-y-3">
                  <div>
                    <label className="block text-sm font-medium mb-1">API Endpoint *</label>
                    <input
                      type="text"
                      value={source.api_config?.endpoint || ''}
                      onChange={(e) => {
                        const newData = data.map((s) =>
                          s.id === source.id
                            ? {
                                ...s,
                                api_config: {
                                  ...s.api_config,
                                  endpoint: e.target.value,
                                  auth_type: s.api_config?.auth_type || 'api_key'
                                }
                              }
                            : s
                        );
                        onChange(newData);
                      }}
                      className="w-full px-3 py-2 border rounded-lg text-sm"
                      placeholder="https://api.example.com/v1"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-1">API Key *</label>
                    <input
                      type="password"
                      value={source.api_config?.api_key || ''}
                      onChange={(e) => {
                        const newData = data.map((s) =>
                          s.id === source.id
                            ? {
                                ...s,
                                api_config: { ...s.api_config, api_key: e.target.value }
                              }
                            : s
                        );
                        onChange(newData);
                      }}
                      className="w-full px-3 py-2 border rounded-lg text-sm"
                      placeholder="Enter your API key"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => handleConnectAPI(source.id)}
                      disabled={!source.api_config?.endpoint || !source.api_config?.api_key}
                      className="px-4 py-2 text-sm bg-blue-600 text-white rounded hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed"
                    >
                      Test Connection
                    </button>
                    <button
                      onClick={() => setApiConfigSource(null)}
                      className="px-4 py-2 text-sm text-gray-600 hover:bg-gray-200 rounded"
                    >
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

