"""
Migration script to add playbook_reports table

This script creates the playbook_reports table for persisting playbook execution reports
across server restarts.

Run: python add_playbook_reports_table.py
"""

import sys
import os

# Add parent directory to path to import app modules
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from app import app, db
from models import PlaybookReport

def create_playbook_reports_table():
    """Create playbook_reports table"""
    with app.app_context():
        # Check if table already exists
        inspector = db.inspect(db.engine)
        if 'playbook_reports' in inspector.get_table_names():
            print("✓ Table 'playbook_reports' already exists")
            return
        
        # Create the table
        PlaybookReport.__table__.create(db.engine)
        print("✓ Created table 'playbook_reports'")
        
        # Verify creation
        inspector = db.inspect(db.engine)
        if 'playbook_reports' in inspector.get_table_names():
            columns = [col['name'] for col in inspector.get_columns('playbook_reports')]
            print(f"✓ Table columns: {', '.join(columns)}")
            print(f"✓ Total columns: {len(columns)}")
        else:
            print("✗ Failed to create table")

if __name__ == '__main__':
    print("Creating playbook_reports table...")
    create_playbook_reports_table()
    print("✓ Migration complete!")

